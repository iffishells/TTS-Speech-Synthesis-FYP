import os
def fun():
    print('hre')
    # os.mkdir('iftikhar.txt')
    os.removedirs('iftikhar.txt')


if __name__ == '__main__':
    fun()