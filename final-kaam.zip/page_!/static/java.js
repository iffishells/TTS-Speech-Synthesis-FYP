var x = document.getElementById("myDIV");
x.style.display = "none";

function audio(form)
{
    x.style.display = "block";
}

//alert("SADsad");